import discord
from discord.ext import commands, tasks
import os
import asyncio
import aiosqlite
from dotenv import load_dotenv
import logging
from datetime import datetime

# إعداد السجلات
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        logging.FileHandler('bot.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('TestBot')

load_dotenv()

TOKEN = os.getenv('TOKEN')
PREFIX = os.getenv('PREFIX', '!')
BOT_NAME = os.getenv('BOT_NAME', 'Test')

# إعداد البوت مع كل الصلاحيات
intents = discord.Intents.all()

class TestBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=commands.when_mentioned_or(PREFIX),
            intents=intents,
            help_command=None,
            case_insensitive=True,
            description=f"بوت {BOT_NAME} المتكامل"
        )
        self.start_time = datetime.utcnow()
        self.db = None

    async def setup_hook(self):
        # تهيئة قاعدة البيانات
        self.db = await aiosqlite.connect('data/database.db')
        await self.init_db()
        
        # تحميل جميع الـ Cogs
        cogs = [
            'cogs.welcome',
            'cogs.leveling',
            'cogs.moderation',
            'cogs.tickets',
            'cogs.economy',
            'cogs.games',
            'cogs.music',
            'cogs.info',
            'cogs.automod',
        ]
        for cog in cogs:
            try:
                await self.load_extension(cog)
                logger.info(f'✅ تم تحميل: {cog}')
            except Exception as e:
                logger.error(f'❌ فشل تحميل {cog}: {e}')
        
        # مزامنة الأوامر السلاشية
        try:
            synced = await self.tree.sync()
            logger.info(f'✅ تمت مزامنة {len(synced)} أمر سلاشي')
        except Exception as e:
            logger.error(f'❌ فشل مزامنة الأوامر: {e}')

    async def init_db(self):
        """تهيئة جداول قاعدة البيانات"""
        await self.db.executescript('''
            CREATE TABLE IF NOT EXISTS levels (
                user_id INTEGER,
                guild_id INTEGER,
                xp INTEGER DEFAULT 0,
                level INTEGER DEFAULT 0,
                messages INTEGER DEFAULT 0,
                PRIMARY KEY (user_id, guild_id)
            );
            
            CREATE TABLE IF NOT EXISTS economy (
                user_id INTEGER,
                guild_id INTEGER,
                balance INTEGER DEFAULT 0,
                bank INTEGER DEFAULT 0,
                last_daily TEXT,
                last_work TEXT,
                PRIMARY KEY (user_id, guild_id)
            );
            
            CREATE TABLE IF NOT EXISTS tickets (
                ticket_id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER,
                user_id INTEGER,
                guild_id INTEGER,
                status TEXT DEFAULT 'open',
                created_at TEXT,
                subject TEXT
            );
            
            CREATE TABLE IF NOT EXISTS warnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                guild_id INTEGER,
                moderator_id INTEGER,
                reason TEXT,
                created_at TEXT
            );
            
            CREATE TABLE IF NOT EXISTS guild_settings (
                guild_id INTEGER PRIMARY KEY,
                welcome_channel INTEGER,
                log_channel INTEGER,
                ticket_category INTEGER,
                level_channel INTEGER,
                mute_role INTEGER,
                auto_role INTEGER,
                prefix TEXT DEFAULT '!'
            );
            
            CREATE TABLE IF NOT EXISTS afk (
                user_id INTEGER,
                guild_id INTEGER,
                reason TEXT,
                time TEXT,
                PRIMARY KEY (user_id, guild_id)
            );
        ''')
        await self.db.commit()
        logger.info('✅ تم تهيئة قاعدة البيانات')

    async def on_ready(self):
        logger.info(f'🚀 {self.user} جاهز للعمل!')
        logger.info(f'📊 في {len(self.guilds)} سيرفر')
        self.change_status.start()

    @tasks.loop(seconds=30)
    async def change_status(self):
        """تغيير الحالة كل 30 ثانية"""
        statuses = [
            discord.Activity(type=discord.ActivityType.watching, name=f"{len(self.guilds)} سيرفر"),
            discord.Activity(type=discord.ActivityType.listening, name=f"{PREFIX}help"),
            discord.Activity(type=discord.ActivityType.playing, name="بوت Test المتكامل 🚀"),
            discord.Activity(type=discord.ActivityType.watching, name=f"{sum(g.member_count for g in self.guilds)} عضو"),
        ]
        import random
        await self.change_presence(
            status=discord.Status.online,
            activity=random.choice(statuses)
        )

    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return
        elif isinstance(error, commands.MissingPermissions):
            embed = discord.Embed(
                title="❌ لا تملك الصلاحية",
                description="ليس لديك صلاحية لاستخدام هذا الأمر.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, delete_after=5)
        elif isinstance(error, commands.MissingRequiredArgument):
            embed = discord.Embed(
                title="⚠️ ناقص معلومة",
                description=f"استخدام خاطئ! اكتب `{PREFIX}help {ctx.command}` للمساعدة.",
                color=discord.Color.orange()
            )
            await ctx.send(embed=embed, delete_after=5)
        elif isinstance(error, commands.CommandOnCooldown):
            embed = discord.Embed(
                title="⏱️ انتظر شوي",
                description=f"الأمر على كولداون. انتظر **{error.retry_after:.1f}** ثانية.",
                color=discord.Color.orange()
            )
            await ctx.send(embed=embed, delete_after=5)
        else:
            logger.error(f'خطأ في الأمر {ctx.command}: {error}')

    async def close(self):
        if self.db:
            await self.db.close()
        await super().close()

bot = TestBot()

@bot.command(name='help')
async def help_command(ctx, category: str = None):
    """أمر المساعدة الشامل"""
    if category is None:
        embed = discord.Embed(
            title="📚 قائمة أوامر بوت Test",
            description=f"استخدم `{PREFIX}help <الفئة>` لرؤية أوامر فئة معينة",
            color=discord.Color.blue()
        )
        embed.add_field(name="🎉 ترحيب", value=f"`{PREFIX}help welcome`", inline=True)
        embed.add_field(name="⭐ المستويات", value=f"`{PREFIX}help leveling`", inline=True)
        embed.add_field(name="🛡️ الإشراف", value=f"`{PREFIX}help moderation`", inline=True)
        embed.add_field(name="🎫 التذاكر", value=f"`{PREFIX}help tickets`", inline=True)
        embed.add_field(name="💰 الاقتصاد", value=f"`{PREFIX}help economy`", inline=True)
        embed.add_field(name="🎮 الألعاب", value=f"`{PREFIX}help games`", inline=True)
        embed.add_field(name="🎵 الموسيقى", value=f"`{PREFIX}help music`", inline=True)
        embed.add_field(name="ℹ️ معلومات", value=f"`{PREFIX}help info`", inline=True)
        embed.set_footer(text=f"البادئة: {PREFIX} | بوت Test المتكامل")
        embed.set_thumbnail(url=bot.user.display_avatar.url)
        await ctx.send(embed=embed)
    else:
        categories = {
            'welcome': {
                'title': '🎉 أوامر الترحيب',
                'commands': [
                    (f'{PREFIX}setwelcome #قناة', 'تعيين قناة الترحيب'),
                    (f'{PREFIX}setleave #قناة', 'تعيين قناة الوداع'),
                    (f'{PREFIX}setautorole @رتبة', 'تعيين رتبة تلقائية للأعضاء الجدد'),
                    (f'{PREFIX}testwelcome', 'اختبار رسالة الترحيب'),
                ]
            },
            'leveling': {
                'title': '⭐ أوامر المستويات',
                'commands': [
                    (f'{PREFIX}rank [@عضو]', 'عرض مستوى عضو'),
                    (f'{PREFIX}leaderboard', 'لوحة الصدارة'),
                    (f'{PREFIX}setlevelchannel #قناة', 'تعيين قناة إشعارات المستوى'),
                    (f'{PREFIX}givexp @عضو <كمية>', 'إعطاء XP لعضو (أدمن)'),
                    (f'{PREFIX}resetxp @عضو', 'إعادة تعيين XP (أدمن)'),
                ]
            },
            'moderation': {
                'title': '🛡️ أوامر الإشراف',
                'commands': [
                    (f'{PREFIX}ban @عضو [سبب]', 'حظر عضو'),
                    (f'{PREFIX}unban <ID>', 'رفع الحظر'),
                    (f'{PREFIX}kick @عضو [سبب]', 'طرد عضو'),
                    (f'{PREFIX}mute @عضو [مدة] [سبب]', 'كتم عضو'),
                    (f'{PREFIX}unmute @عضو', 'رفع الكتم'),
                    (f'{PREFIX}warn @عضو [سبب]', 'تحذير عضو'),
                    (f'{PREFIX}warnings @عضو', 'عرض تحذيرات عضو'),
                    (f'{PREFIX}clearwarns @عضو', 'مسح تحذيرات عضو'),
                    (f'{PREFIX}clear <عدد>', 'مسح رسائل'),
                    (f'{PREFIX}slowmode <ثواني>', 'تفعيل السلو مود'),
                    (f'{PREFIX}lock', 'قفل القناة'),
                    (f'{PREFIX}unlock', 'فتح القناة'),
                ]
            },
            'tickets': {
                'title': '🎫 أوامر التذاكر',
                'commands': [
                    (f'{PREFIX}ticket [موضوع]', 'فتح تذكرة دعم'),
                    (f'{PREFIX}close', 'إغلاق التذكرة'),
                    (f'{PREFIX}adduser @عضو', 'إضافة عضو للتذكرة'),
                    (f'{PREFIX}removeuser @عضو', 'إزالة عضو من التذكرة'),
                    (f'{PREFIX}setupticket', 'إعداد نظام التذاكر (أدمن)'),
                ]
            },
            'economy': {
                'title': '💰 أوامر الاقتصاد',
                'commands': [
                    (f'{PREFIX}balance [@عضو]', 'عرض الرصيد'),
                    (f'{PREFIX}daily', 'مكافأة يومية'),
                    (f'{PREFIX}work', 'اشتغل وكسب فلوس'),
                    (f'{PREFIX}deposit <كمية>', 'إيداع في البنك'),
                    (f'{PREFIX}withdraw <كمية>', 'سحب من البنك'),
                    (f'{PREFIX}transfer @عضو <كمية>', 'تحويل فلوس'),
                    (f'{PREFIX}richlist', 'أغنى الأعضاء'),
                ]
            },
            'games': {
                'title': '🎮 أوامر الألعاب',
                'commands': [
                    (f'{PREFIX}coinflip [مبلغ]', 'رمي عملة'),
                    (f'{PREFIX}dice [مبلغ]', 'رمي نرد'),
                    (f'{PREFIX}rps <حجر/ورقة/مقص>', 'حجر ورقة مقص'),
                    (f'{PREFIX}trivia', 'سؤال ثقافي'),
                    (f'{PREFIX}8ball <سؤال>', 'كرة السحر'),
                    (f'{PREFIX}slots [مبلغ]', 'سلوت ماشين'),
                    (f'{PREFIX}guess', 'خمن الرقم'),
                ]
            },
            'music': {
                'title': '🎵 أوامر الموسيقى',
                'commands': [
                    (f'{PREFIX}play <اسم/رابط>', 'تشغيل موسيقى'),
                    (f'{PREFIX}pause', 'إيقاف مؤقت'),
                    (f'{PREFIX}resume', 'استئناف التشغيل'),
                    (f'{PREFIX}skip', 'تخطي الأغنية'),
                    (f'{PREFIX}stop', 'إيقاف الموسيقى'),
                    (f'{PREFIX}queue', 'عرض قائمة الانتظار'),
                    (f'{PREFIX}volume <0-100>', 'ضبط الصوت'),
                    (f'{PREFIX}nowplaying', 'الأغنية الحالية'),
                    (f'{PREFIX}loop', 'تكرار الأغنية'),
                ]
            },
            'info': {
                'title': 'ℹ️ أوامر المعلومات',
                'commands': [
                    (f'{PREFIX}userinfo [@عضو]', 'معلومات عضو'),
                    (f'{PREFIX}serverinfo', 'معلومات السيرفر'),
                    (f'{PREFIX}roleinfo @رتبة', 'معلومات رتبة'),
                    (f'{PREFIX}avatar [@عضو]', 'صورة عضو'),
                    (f'{PREFIX}ping', 'سرعة البوت'),
                    (f'{PREFIX}uptime', 'مدة تشغيل البوت'),
                    (f'{PREFIX}afk [سبب]', 'تفعيل وضع AFK'),
                    (f'{PREFIX}botinfo', 'معلومات البوت'),
                ]
            },
        }
        
        cat = categories.get(category.lower())
        if cat:
            embed = discord.Embed(title=cat['title'], color=discord.Color.blue())
            for cmd, desc in cat['commands']:
                embed.add_field(name=f'`{cmd}`', value=desc, inline=False)
            embed.set_footer(text=f"البادئة: {PREFIX}")
            await ctx.send(embed=embed)
        else:
            await ctx.send(f"❌ الفئة غير موجودة. استخدم `{PREFIX}help` لرؤية الفئات المتاحة.")

if __name__ == '__main__':
    # تفعيل keep_alive للاستضافة المجانية
    try:
        from keep_alive import keep_alive
        keep_alive()
    except:
        pass
    
    bot.run(TOKEN, log_handler=None)
