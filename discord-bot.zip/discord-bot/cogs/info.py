import discord
from discord.ext import commands
import aiosqlite
from datetime import datetime

class Info(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='userinfo', aliases=['ui', 'whois'])
    async def userinfo(self, ctx, member: discord.Member = None):
        """معلومات عضو"""
        member = member or ctx.author
        
        roles = [r.mention for r in member.roles[1:]][:10]
        roles_str = ", ".join(roles) if roles else "لا توجد رتب"
        
        embed = discord.Embed(
            title=f"👤 معلومات {member.display_name}",
            color=member.color if member.color != discord.Color.default() else discord.Color.blue()
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="الاسم الكامل", value=str(member), inline=True)
        embed.add_field(name="ID", value=str(member.id), inline=True)
        embed.add_field(name="البوت؟", value="نعم ✅" if member.bot else "لا ❌", inline=True)
        embed.add_field(name="تاريخ إنشاء الحساب", value=member.created_at.strftime("%Y-%m-%d"), inline=True)
        embed.add_field(name="تاريخ الانضمام", value=member.joined_at.strftime("%Y-%m-%d") if member.joined_at else "غير معروف", inline=True)
        embed.add_field(name="الحالة", value=str(member.status).title(), inline=True)
        embed.add_field(name=f"الرتب ({len(member.roles)-1})", value=roles_str, inline=False)
        embed.set_footer(text=f"طلب بواسطة {ctx.author.display_name}")
        await ctx.send(embed=embed)

    @commands.command(name='serverinfo', aliases=['si', 'server'])
    async def serverinfo(self, ctx):
        """معلومات السيرفر"""
        guild = ctx.guild
        
        bots = sum(1 for m in guild.members if m.bot)
        humans = guild.member_count - bots
        
        embed = discord.Embed(
            title=f"🏠 معلومات {guild.name}",
            color=discord.Color.blue()
        )
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        
        embed.add_field(name="المالك", value=guild.owner.mention if guild.owner else "غير معروف", inline=True)
        embed.add_field(name="ID", value=str(guild.id), inline=True)
        embed.add_field(name="تاريخ الإنشاء", value=guild.created_at.strftime("%Y-%m-%d"), inline=True)
        embed.add_field(name="إجمالي الأعضاء", value=f"**{guild.member_count}**", inline=True)
        embed.add_field(name="البشر", value=f"**{humans}**", inline=True)
        embed.add_field(name="البوتات", value=f"**{bots}**", inline=True)
        embed.add_field(name="القنوات النصية", value=f"**{len(guild.text_channels)}**", inline=True)
        embed.add_field(name="القنوات الصوتية", value=f"**{len(guild.voice_channels)}**", inline=True)
        embed.add_field(name="الرتب", value=f"**{len(guild.roles)}**", inline=True)
        embed.add_field(name="الإيموجي", value=f"**{len(guild.emojis)}**", inline=True)
        embed.add_field(name="مستوى التحقق", value=str(guild.verification_level).title(), inline=True)
        embed.add_field(name="Boosts", value=f"**{guild.premium_subscription_count}** (المستوى {guild.premium_tier})", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name='avatar', aliases=['av', 'pfp'])
    async def avatar(self, ctx, member: discord.Member = None):
        """عرض صورة عضو"""
        member = member or ctx.author
        embed = discord.Embed(
            title=f"🖼️ صورة {member.display_name}",
            color=discord.Color.blue()
        )
        embed.set_image(url=member.display_avatar.url)
        embed.add_field(name="PNG", value=f"[رابط]({member.display_avatar.with_format('png').url})", inline=True)
        embed.add_field(name="JPG", value=f"[رابط]({member.display_avatar.with_format('jpg').url})", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name='ping')
    async def ping(self, ctx):
        """سرعة البوت"""
        latency = round(self.bot.latency * 1000)
        color = discord.Color.green() if latency < 100 else discord.Color.yellow() if latency < 200 else discord.Color.red()
        embed = discord.Embed(
            title="🏓 Pong!",
            description=f"سرعة البوت: **{latency}ms**",
            color=color
        )
        await ctx.send(embed=embed)

    @commands.command(name='uptime')
    async def uptime(self, ctx):
        """مدة تشغيل البوت"""
        delta = datetime.utcnow() - self.bot.start_time
        days = delta.days
        hours, remainder = divmod(delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        embed = discord.Embed(
            title="⏱️ مدة التشغيل",
            description=f"**{days}** يوم، **{hours}** ساعة، **{minutes}** دقيقة، **{seconds}** ثانية",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    @commands.command(name='roleinfo', aliases=['ri'])
    async def roleinfo(self, ctx, role: discord.Role):
        """معلومات رتبة"""
        embed = discord.Embed(
            title=f"🎭 معلومات رتبة: {role.name}",
            color=role.color
        )
        embed.add_field(name="ID", value=str(role.id), inline=True)
        embed.add_field(name="اللون", value=str(role.color), inline=True)
        embed.add_field(name="الأعضاء", value=f"**{len(role.members)}**", inline=True)
        embed.add_field(name="قابلة للذكر", value="نعم" if role.mentionable else "لا", inline=True)
        embed.add_field(name="مُعلّقة", value="نعم" if role.hoist else "لا", inline=True)
        embed.add_field(name="تاريخ الإنشاء", value=role.created_at.strftime("%Y-%m-%d"), inline=True)
        await ctx.send(embed=embed)

    @commands.command(name='afk')
    async def afk(self, ctx, *, reason="غائب"):
        """تفعيل وضع AFK"""
        async with aiosqlite.connect('data/database.db') as db:
            await db.execute('''
                INSERT INTO afk (user_id, guild_id, reason, time)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id, guild_id) DO UPDATE SET reason = ?, time = ?
            ''', (ctx.author.id, ctx.guild.id, reason, datetime.utcnow().isoformat(), reason, datetime.utcnow().isoformat()))
            await db.commit()
        
        embed = discord.Embed(
            title="💤 وضع AFK مفعّل",
            description=f"تم تفعيل AFK لـ {ctx.author.mention}\n**السبب:** {reason}",
            color=discord.Color.blue()
        )
        await ctx.send(embed=embed)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return
        
        # التحقق من AFK
        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute(
                'SELECT reason FROM afk WHERE user_id = ? AND guild_id = ?',
                (message.author.id, message.guild.id if message.guild else 0)
            ) as cursor:
                afk_row = await cursor.fetchone()
        
        if afk_row:
            async with aiosqlite.connect('data/database.db') as db:
                await db.execute('DELETE FROM afk WHERE user_id = ? AND guild_id = ?',
                    (message.author.id, message.guild.id if message.guild else 0))
                await db.commit()
            await message.channel.send(f"👋 مرحباً {message.author.mention}! تم إلغاء AFK.", delete_after=5)
        
        # إشعار المذكورين بـ AFK
        if message.guild and message.mentions:
            for mentioned in message.mentions:
                async with aiosqlite.connect('data/database.db') as db:
                    async with db.execute(
                        'SELECT reason, time FROM afk WHERE user_id = ? AND guild_id = ?',
                        (mentioned.id, message.guild.id)
                    ) as cursor:
                        row = await cursor.fetchone()
                if row:
                    await message.channel.send(
                        f"💤 **{mentioned.display_name}** في وضع AFK: {row[0]}",
                        delete_after=10
                    )

    @commands.command(name='botinfo')
    async def botinfo(self, ctx):
        """معلومات البوت"""
        embed = discord.Embed(
            title=f"🤖 معلومات بوت {self.bot.user.name}",
            color=discord.Color.blue()
        )
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.add_field(name="الاسم", value=str(self.bot.user), inline=True)
        embed.add_field(name="ID", value=str(self.bot.user.id), inline=True)
        embed.add_field(name="السيرفرات", value=f"**{len(self.bot.guilds)}**", inline=True)
        embed.add_field(name="الأعضاء", value=f"**{sum(g.member_count for g in self.bot.guilds):,}**", inline=True)
        embed.add_field(name="البادئة", value=f"`{ctx.prefix}`", inline=True)
        embed.add_field(name="المكتبة", value="discord.py", inline=True)
        
        delta = datetime.utcnow() - self.bot.start_time
        hours, remainder = divmod(delta.seconds, 3600)
        minutes, _ = divmod(remainder, 60)
        embed.add_field(name="وقت التشغيل", value=f"{delta.days}d {hours}h {minutes}m", inline=True)
        embed.add_field(name="Ping", value=f"{round(self.bot.latency * 1000)}ms", inline=True)
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Info(bot))
