import discord
from discord.ext import commands
import aiosqlite
from datetime import datetime

class TicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="🎫 فتح تذكرة", style=discord.ButtonStyle.green, custom_id="open_ticket")
    async def open_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        user = interaction.user

        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute(
                'SELECT channel_id FROM tickets WHERE user_id = ? AND guild_id = ? AND status = "open"',
                (user.id, guild.id)
            ) as cursor:
                existing = await cursor.fetchone()

        if existing:
            channel = guild.get_channel(existing[0])
            if channel:
                return await interaction.response.send_message(
                    f"❌ لديك تذكرة مفتوحة بالفعل: {channel.mention}", ephemeral=True
                )

        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute('SELECT ticket_category FROM guild_settings WHERE guild_id = ?', (guild.id,)) as cursor:
                row = await cursor.fetchone()

        category = guild.get_channel(row[0]) if row and row[0] else None

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
            guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True),
        }

        for role in guild.roles:
            if role.permissions.manage_guild:
                overwrites[role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)

        channel = await guild.create_text_channel(
            name=f"ticket-{user.name}",
            category=category,
            overwrites=overwrites,
            topic=f"تذكرة دعم لـ {user}"
        )

        async with aiosqlite.connect('data/database.db') as db:
            await db.execute(
                'INSERT INTO tickets (channel_id, user_id, guild_id, status, created_at) VALUES (?, ?, ?, "open", ?)',
                (channel.id, user.id, guild.id, datetime.utcnow().isoformat())
            )
            await db.commit()

        embed = discord.Embed(
            title="🎫 تذكرة دعم",
            description=(
                f"مرحباً {user.mention}!\n\n"
                "شكراً لتواصلك معنا. سيقوم أحد أعضاء الفريق بمساعدتك قريباً.\n\n"
                "**لإغلاق التذكرة:** اضغط على زر الإغلاق أدناه."
            ),
            color=discord.Color.blue()
        )
        embed.set_footer(text=f"تذكرة بواسطة {user.display_name}")

        view = CloseTicketView()
        await channel.send(embed=embed, view=view)
        await interaction.response.send_message(f"✅ تم فتح تذكرتك: {channel.mention}", ephemeral=True)


class CloseTicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="🔒 إغلاق التذكرة", style=discord.ButtonStyle.red, custom_id="close_ticket")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = interaction.channel
        embed = discord.Embed(
            title="🔒 إغلاق التذكرة",
            description="سيتم إغلاق هذه التذكرة خلال 5 ثواني...",
            color=discord.Color.red()
        )
        await interaction.response.send_message(embed=embed)

        async with aiosqlite.connect('data/database.db') as db:
            await db.execute(
                'UPDATE tickets SET status = "closed" WHERE channel_id = ?',
                (channel.id,)
            )
            await db.commit()

        import asyncio
        await asyncio.sleep(5)
        await channel.delete(reason="إغلاق التذكرة")


class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        self.bot.add_view(TicketView())
        self.bot.add_view(CloseTicketView())

    @commands.command(name='setupticket')
    @commands.has_permissions(administrator=True)
    async def setup_ticket(self, ctx, category: discord.CategoryChannel = None):
        """إعداد نظام التذاكر"""
        if category:
            async with aiosqlite.connect('data/database.db') as db:
                await db.execute('''
                    INSERT INTO guild_settings (guild_id, ticket_category)
                    VALUES (?, ?)
                    ON CONFLICT(guild_id) DO UPDATE SET ticket_category = ?
                ''', (ctx.guild.id, category.id, category.id))
                await db.commit()

        embed = discord.Embed(
            title="🎫 نظام التذاكر",
            description=(
                "**مرحباً بك في نظام الدعم!**\n\n"
                "اضغط على الزر أدناه لفتح تذكرة دعم وسيتواصل معك أحد أعضاء الفريق.\n\n"
                "⚠️ يرجى عدم فتح تذاكر عشوائية."
            ),
            color=discord.Color.blue()
        )
        embed.set_footer(text=ctx.guild.name)

        view = TicketView()
        await ctx.send(embed=embed, view=view)

    @commands.command(name='ticket')
    async def ticket(self, ctx, *, subject="لا يوجد موضوع"):
        """فتح تذكرة دعم"""
        guild = ctx.guild
        user = ctx.author

        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute(
                'SELECT channel_id FROM tickets WHERE user_id = ? AND guild_id = ? AND status = "open"',
                (user.id, guild.id)
            ) as cursor:
                existing = await cursor.fetchone()

        if existing:
            channel = guild.get_channel(existing[0])
            if channel:
                return await ctx.send(f"❌ لديك تذكرة مفتوحة بالفعل: {channel.mention}")

        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute('SELECT ticket_category FROM guild_settings WHERE guild_id = ?', (guild.id,)) as cursor:
                row = await cursor.fetchone()

        category = guild.get_channel(row[0]) if row and row[0] else None

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
            guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True),
        }

        channel = await guild.create_text_channel(
            name=f"ticket-{user.name}",
            category=category,
            overwrites=overwrites
        )

        async with aiosqlite.connect('data/database.db') as db:
            await db.execute(
                'INSERT INTO tickets (channel_id, user_id, guild_id, status, created_at, subject) VALUES (?, ?, ?, "open", ?, ?)',
                (channel.id, user.id, guild.id, datetime.utcnow().isoformat(), subject)
            )
            await db.commit()

        embed = discord.Embed(
            title="🎫 تذكرة دعم",
            description=f"مرحباً {user.mention}!\n**الموضوع:** {subject}\n\nسيتواصل معك الفريق قريباً.",
            color=discord.Color.blue()
        )
        view = CloseTicketView()
        await channel.send(embed=embed, view=view)
        await ctx.send(f"✅ تم فتح تذكرتك: {channel.mention}")

    @commands.command(name='close')
    async def close(self, ctx):
        """إغلاق التذكرة الحالية"""
        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute(
                'SELECT ticket_id FROM tickets WHERE channel_id = ? AND status = "open"',
                (ctx.channel.id,)
            ) as cursor:
                row = await cursor.fetchone()

        if not row:
            return await ctx.send("❌ هذه القناة ليست تذكرة مفتوحة")

        await ctx.send("🔒 سيتم إغلاق التذكرة خلال 5 ثواني...")

        async with aiosqlite.connect('data/database.db') as db:
            await db.execute('UPDATE tickets SET status = "closed" WHERE channel_id = ?', (ctx.channel.id,))
            await db.commit()

        import asyncio
        await asyncio.sleep(5)
        await ctx.channel.delete(reason="إغلاق التذكرة")

    @commands.command(name='adduser')
    @commands.has_permissions(manage_channels=True)
    async def add_user(self, ctx, member: discord.Member):
        """إضافة عضو للتذكرة"""
        await ctx.channel.set_permissions(member, read_messages=True, send_messages=True)
        await ctx.send(f"✅ تمت إضافة {member.mention} للتذكرة")

    @commands.command(name='removeuser')
    @commands.has_permissions(manage_channels=True)
    async def remove_user(self, ctx, member: discord.Member):
        """إزالة عضو من التذكرة"""
        await ctx.channel.set_permissions(member, read_messages=False)
        await ctx.send(f"✅ تمت إزالة {member.mention} من التذكرة")

async def setup(bot):
    await bot.add_cog(Tickets(bot))
