import discord
from discord.ext import commands
import asyncio
import yt_dlp
from collections import deque

YDL_OPTIONS = {
    'format': 'bestaudio/best',
    'noplaylist': True,
    'quiet': True,
    'no_warnings': True,
    'default_search': 'ytsearch',
    'source_address': '0.0.0.0',
    'postprocessors': [{
        'key': 'FFmpegExtractAudio',
        'preferredcodec': 'mp3',
        'preferredquality': '192',
    }],
}

FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn'
}

class MusicQueue:
    def __init__(self):
        self.queue = deque()
        self.current = None
        self.loop = False
        self.volume = 0.5

class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.queues = {}

    def get_queue(self, guild_id):
        if guild_id not in self.queues:
            self.queues[guild_id] = MusicQueue()
        return self.queues[guild_id]

    async def search_song(self, query):
        with yt_dlp.YoutubeDL(YDL_OPTIONS) as ydl:
            try:
                if not query.startswith('http'):
                    query = f"ytsearch:{query}"
                info = ydl.extract_info(query, download=False)
                if 'entries' in info:
                    info = info['entries'][0]
                return {
                    'url': info['url'],
                    'title': info.get('title', 'Unknown'),
                    'duration': info.get('duration', 0),
                    'thumbnail': info.get('thumbnail', ''),
                    'webpage_url': info.get('webpage_url', ''),
                }
            except Exception as e:
                return None

    def play_next(self, ctx):
        queue = self.get_queue(ctx.guild.id)
        
        if queue.loop and queue.current:
            song = queue.current
        elif queue.queue:
            song = queue.queue.popleft()
            queue.current = song
        else:
            queue.current = None
            asyncio.run_coroutine_threadsafe(
                ctx.send(embed=discord.Embed(title="🎵 انتهت قائمة الانتظار", color=discord.Color.blue())),
                self.bot.loop
            )
            return

        source = discord.FFmpegPCMAudio(song['url'], **FFMPEG_OPTIONS)
        source = discord.PCMVolumeTransformer(source, volume=queue.volume)
        
        ctx.voice_client.play(
            source,
            after=lambda e: self.play_next(ctx) if not e else None
        )

    @commands.command(name='play', aliases=['p'])
    async def play(self, ctx, *, query: str):
        """تشغيل موسيقى"""
        if not ctx.author.voice:
            return await ctx.send("❌ يجب أن تكون في روم صوتي!")

        voice_channel = ctx.author.voice.channel

        if ctx.voice_client is None:
            await voice_channel.connect()
        elif ctx.voice_client.channel != voice_channel:
            await ctx.voice_client.move_to(voice_channel)

        async with ctx.typing():
            embed = discord.Embed(title="🔍 جاري البحث...", color=discord.Color.blue())
            msg = await ctx.send(embed=embed)
            
            song = await self.search_song(query)
            
            if not song:
                return await msg.edit(embed=discord.Embed(title="❌ لم يتم العثور على الأغنية", color=discord.Color.red()))

        queue = self.get_queue(ctx.guild.id)
        
        duration_str = f"{song['duration']//60}:{song['duration']%60:02d}" if song['duration'] else "غير معروف"
        
        if ctx.voice_client.is_playing() or ctx.voice_client.is_paused():
            queue.queue.append(song)
            embed = discord.Embed(
                title="➕ أُضيفت للقائمة",
                description=f"[{song['title']}]({song['webpage_url']})",
                color=discord.Color.blue()
            )
            embed.add_field(name="المدة", value=duration_str, inline=True)
            embed.add_field(name="الموضع في القائمة", value=f"#{len(queue.queue)}", inline=True)
            if song['thumbnail']:
                embed.set_thumbnail(url=song['thumbnail'])
            await msg.edit(embed=embed)
        else:
            queue.current = song
            source = discord.FFmpegPCMAudio(song['url'], **FFMPEG_OPTIONS)
            source = discord.PCMVolumeTransformer(source, volume=queue.volume)
            ctx.voice_client.play(source, after=lambda e: self.play_next(ctx) if not e else None)
            
            embed = discord.Embed(
                title="🎵 يتم التشغيل الآن",
                description=f"[{song['title']}]({song['webpage_url']})",
                color=discord.Color.green()
            )
            embed.add_field(name="المدة", value=duration_str, inline=True)
            if song['thumbnail']:
                embed.set_thumbnail(url=song['thumbnail'])
            await msg.edit(embed=embed)

    @commands.command(name='pause')
    async def pause(self, ctx):
        """إيقاف مؤقت"""
        if ctx.voice_client and ctx.voice_client.is_playing():
            ctx.voice_client.pause()
            await ctx.send(embed=discord.Embed(title="⏸️ تم الإيقاف المؤقت", color=discord.Color.yellow()))
        else:
            await ctx.send("❌ لا يوجد شيء يعزف الآن")

    @commands.command(name='resume')
    async def resume(self, ctx):
        """استئناف التشغيل"""
        if ctx.voice_client and ctx.voice_client.is_paused():
            ctx.voice_client.resume()
            await ctx.send(embed=discord.Embed(title="▶️ تم الاستئناف", color=discord.Color.green()))
        else:
            await ctx.send("❌ الموسيقى ليست متوقفة")

    @commands.command(name='skip', aliases=['s'])
    async def skip(self, ctx):
        """تخطي الأغنية الحالية"""
        if ctx.voice_client and ctx.voice_client.is_playing():
            ctx.voice_client.stop()
            await ctx.send(embed=discord.Embed(title="⏭️ تم التخطي", color=discord.Color.blue()))
        else:
            await ctx.send("❌ لا يوجد شيء يعزف الآن")

    @commands.command(name='stop')
    async def stop(self, ctx):
        """إيقاف الموسيقى وإفراغ القائمة"""
        queue = self.get_queue(ctx.guild.id)
        queue.queue.clear()
        queue.current = None
        if ctx.voice_client:
            ctx.voice_client.stop()
            await ctx.voice_client.disconnect()
        await ctx.send(embed=discord.Embed(title="⏹️ تم الإيقاف", color=discord.Color.red()))

    @commands.command(name='queue', aliases=['q'])
    async def queue_cmd(self, ctx):
        """عرض قائمة الانتظار"""
        queue = self.get_queue(ctx.guild.id)
        
        embed = discord.Embed(title="🎵 قائمة الانتظار", color=discord.Color.blue())
        
        if queue.current:
            embed.add_field(
                name="🎵 يعزف الآن",
                value=f"[{queue.current['title']}]({queue.current['webpage_url']})",
                inline=False
            )
        
        if queue.queue:
            songs_list = ""
            for i, song in enumerate(list(queue.queue)[:10], 1):
                songs_list += f"`{i}.` {song['title']}\n"
            embed.add_field(name=f"📋 القائمة ({len(queue.queue)} أغنية)", value=songs_list, inline=False)
        else:
            embed.add_field(name="📋 القائمة", value="فارغة", inline=False)
        
        embed.add_field(name="🔁 تكرار", value="مفعّل" if queue.loop else "معطّل", inline=True)
        embed.add_field(name="🔊 الصوت", value=f"{int(queue.volume * 100)}%", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name='volume', aliases=['vol'])
    async def volume(self, ctx, vol: int):
        """ضبط الصوت (0-100)"""
        if not 0 <= vol <= 100:
            return await ctx.send("❌ الصوت يجب أن يكون بين 0 و 100")
        
        queue = self.get_queue(ctx.guild.id)
        queue.volume = vol / 100
        
        if ctx.voice_client and ctx.voice_client.source:
            ctx.voice_client.source.volume = queue.volume
        
        await ctx.send(embed=discord.Embed(title=f"🔊 الصوت: {vol}%", color=discord.Color.blue()))

    @commands.command(name='nowplaying', aliases=['np'])
    async def nowplaying(self, ctx):
        """الأغنية الحالية"""
        queue = self.get_queue(ctx.guild.id)
        if not queue.current:
            return await ctx.send("❌ لا يوجد شيء يعزف الآن")
        
        song = queue.current
        embed = discord.Embed(
            title="🎵 يعزف الآن",
            description=f"[{song['title']}]({song['webpage_url']})",
            color=discord.Color.green()
        )
        if song['thumbnail']:
            embed.set_thumbnail(url=song['thumbnail'])
        await ctx.send(embed=embed)

    @commands.command(name='loop')
    async def loop(self, ctx):
        """تفعيل/إيقاف تكرار الأغنية"""
        queue = self.get_queue(ctx.guild.id)
        queue.loop = not queue.loop
        status = "مفعّل 🔁" if queue.loop else "معطّل ➡️"
        await ctx.send(embed=discord.Embed(title=f"التكرار: {status}", color=discord.Color.blue()))

    @commands.command(name='leave', aliases=['disconnect', 'dc'])
    async def leave(self, ctx):
        """مغادرة الروم الصوتي"""
        if ctx.voice_client:
            await ctx.voice_client.disconnect()
            await ctx.send(embed=discord.Embed(title="👋 تمت المغادرة", color=discord.Color.blue()))

async def setup(bot):
    await bot.add_cog(Music(bot))
