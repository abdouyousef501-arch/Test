import discord
from discord.ext import commands
import aiosqlite
from datetime import datetime, timedelta
import re

def parse_time(time_str):
    units = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400}
    match = re.match(r'(\d+)([smhd])', time_str.lower())
    if match:
        return int(match.group(1)) * units[match.group(2)]
    return None

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def log_action(self, guild, action, moderator, target, reason):
        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute('SELECT log_channel FROM guild_settings WHERE guild_id = ?', (guild.id,)) as cursor:
                row = await cursor.fetchone()
        if row and row[0]:
            channel = guild.get_channel(row[0])
            if channel:
                colors = {'حظر': discord.Color.red(), 'طرد': discord.Color.orange(), 'كتم': discord.Color.yellow(), 'تحذير': discord.Color.gold()}
                embed = discord.Embed(title=f"🔨 إجراء: {action}", color=colors.get(action, discord.Color.blue()), timestamp=datetime.utcnow())
                embed.add_field(name="العضو", value=f"{target} ({target.id})", inline=True)
                embed.add_field(name="المشرف", value=f"{moderator}", inline=True)
                embed.add_field(name="السبب", value=reason or "لم يُذكر", inline=False)
                await channel.send(embed=embed)

    @commands.command(name='ban')
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason="لم يُذكر"):
        if member.top_role >= ctx.author.top_role:
            return await ctx.send("❌ لا تستطيع حظر هذا العضو")
        await member.ban(reason=f"{reason} | بواسطة: {ctx.author}")
        embed = discord.Embed(title="🔨 تم الحظر", description=f"تم حظر **{member}**\n**السبب:** {reason}", color=discord.Color.red())
        await ctx.send(embed=embed)
        await self.log_action(ctx.guild, "حظر", ctx.author, member, reason)

    @commands.command(name='unban')
    @commands.has_permissions(ban_members=True)
    async def unban(self, ctx, user_id: int, *, reason="لم يُذكر"):
        try:
            user = await self.bot.fetch_user(user_id)
            await ctx.guild.unban(user, reason=reason)
            await ctx.send(embed=discord.Embed(title="✅ تم رفع الحظر", description=f"تم رفع حظر **{user}**", color=discord.Color.green()))
        except discord.NotFound:
            await ctx.send("❌ المستخدم غير موجود أو ليس محظوراً")

    @commands.command(name='kick')
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason="لم يُذكر"):
        if member.top_role >= ctx.author.top_role:
            return await ctx.send("❌ لا تستطيع طرد هذا العضو")
        await member.kick(reason=f"{reason} | بواسطة: {ctx.author}")
        embed = discord.Embed(title="👢 تم الطرد", description=f"تم طرد **{member}**\n**السبب:** {reason}", color=discord.Color.orange())
        await ctx.send(embed=embed)
        await self.log_action(ctx.guild, "طرد", ctx.author, member, reason)

    @commands.command(name='mute')
    @commands.has_permissions(moderate_members=True)
    async def mute(self, ctx, member: discord.Member, duration: str = "10m", *, reason="لم يُذكر"):
        seconds = parse_time(duration)
        if not seconds:
            return await ctx.send("❌ صيغة الوقت خاطئة. استخدم: 10s, 5m, 2h, 1d")
        until = datetime.utcnow() + timedelta(seconds=seconds)
        await member.timeout(until, reason=reason)
        embed = discord.Embed(title="🔇 تم الكتم", description=f"تم كتم **{member}** لمدة **{duration}**\n**السبب:** {reason}", color=discord.Color.yellow())
        await ctx.send(embed=embed)
        await self.log_action(ctx.guild, "كتم", ctx.author, member, reason)

    @commands.command(name='unmute')
    @commands.has_permissions(moderate_members=True)
    async def unmute(self, ctx, member: discord.Member):
        await member.timeout(None)
        await ctx.send(embed=discord.Embed(title="🔊 تم رفع الكتم", description=f"تم رفع كتم **{member}**", color=discord.Color.green()))

    @commands.command(name='warn')
    @commands.has_permissions(manage_messages=True)
    async def warn(self, ctx, member: discord.Member, *, reason="لم يُذكر"):
        async with aiosqlite.connect('data/database.db') as db:
            await db.execute('INSERT INTO warnings (user_id, guild_id, moderator_id, reason, created_at) VALUES (?, ?, ?, ?, ?)',
                (member.id, ctx.guild.id, ctx.author.id, reason, datetime.utcnow().isoformat()))
            await db.commit()
            async with db.execute('SELECT COUNT(*) FROM warnings WHERE user_id = ? AND guild_id = ?', (member.id, ctx.guild.id)) as cursor:
                count = (await cursor.fetchone())[0]
        embed = discord.Embed(title="⚠️ تحذير", description=f"تم تحذير **{member}**\n**السبب:** {reason}\n**عدد التحذيرات:** {count}", color=discord.Color.gold())
        await ctx.send(embed=embed)
        try:
            await member.send(embed=discord.Embed(title=f"⚠️ تحذير من {ctx.guild.name}", description=f"**السبب:** {reason}\n**عدد تحذيراتك:** {count}", color=discord.Color.gold()))
        except:
            pass
        await self.log_action(ctx.guild, "تحذير", ctx.author, member, reason)

    @commands.command(name='warnings')
    async def warnings(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute('SELECT reason, moderator_id, created_at FROM warnings WHERE user_id = ? AND guild_id = ? ORDER BY created_at DESC', (member.id, ctx.guild.id)) as cursor:
                rows = await cursor.fetchall()
        if not rows:
            return await ctx.send(f"✅ {member.mention} ليس لديه تحذيرات")
        embed = discord.Embed(title=f"⚠️ تحذيرات {member.display_name} ({len(rows)})", color=discord.Color.gold())
        for i, (reason, mod_id, created_at) in enumerate(rows[:10], 1):
            mod = ctx.guild.get_member(mod_id)
            mod_name = mod.display_name if mod else f"ID: {mod_id}"
            embed.add_field(name=f"#{i} - {created_at[:10]}", value=f"**السبب:** {reason}\n**المشرف:** {mod_name}", inline=False)
        await ctx.send(embed=embed)

    @commands.command(name='clearwarns')
    @commands.has_permissions(administrator=True)
    async def clear_warns(self, ctx, member: discord.Member):
        async with aiosqlite.connect('data/database.db') as db:
            await db.execute('DELETE FROM warnings WHERE user_id = ? AND guild_id = ?', (member.id, ctx.guild.id))
            await db.commit()
        await ctx.send(f"✅ تم مسح جميع تحذيرات {member.mention}")

    @commands.command(name='clear', aliases=['purge'])
    @commands.has_permissions(manage_messages=True)
    async def clear(self, ctx, amount: int = 10):
        if amount > 100:
            return await ctx.send("❌ لا يمكن مسح أكثر من 100 رسالة")
        deleted = await ctx.channel.purge(limit=amount + 1)
        msg = await ctx.send(embed=discord.Embed(title="🗑️ تم المسح", description=f"تم مسح **{len(deleted)-1}** رسالة", color=discord.Color.green()))
        await msg.delete(delay=3)

    @commands.command(name='slowmode')
    @commands.has_permissions(manage_channels=True)
    async def slowmode(self, ctx, seconds: int = 0):
        await ctx.channel.edit(slowmode_delay=seconds)
        if seconds == 0:
            await ctx.send("✅ تم إيقاف السلو مود")
        else:
            await ctx.send(f"✅ تم تفعيل السلو مود: **{seconds}** ثانية")

    @commands.command(name='lock')
    @commands.has_permissions(manage_channels=True)
    async def lock(self, ctx):
        await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=False)
        await ctx.send(embed=discord.Embed(title="🔒 القناة مقفلة", description="تم قفل هذه القناة من قِبل الإدارة", color=discord.Color.red()))

    @commands.command(name='unlock')
    @commands.has_permissions(manage_channels=True)
    async def unlock(self, ctx):
        await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=True)
        await ctx.send(embed=discord.Embed(title="🔓 القناة مفتوحة", description="تم فتح هذه القناة", color=discord.Color.green()))

    @commands.command(name='setlog')
    @commands.has_permissions(administrator=True)
    async def set_log(self, ctx, channel: discord.TextChannel):
        async with aiosqlite.connect('data/database.db') as db:
            await db.execute('INSERT INTO guild_settings (guild_id, log_channel) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET log_channel = ?', (ctx.guild.id, channel.id, channel.id))
            await db.commit()
        await ctx.send(f"✅ تم تعيين قناة السجلات على {channel.mention}")

async def setup(bot):
    await bot.add_cog(Moderation(bot))
