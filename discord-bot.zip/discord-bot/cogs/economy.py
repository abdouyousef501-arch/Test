import discord
from discord.ext import commands
import aiosqlite
import random
from datetime import datetime, timedelta

DAILY_AMOUNT = 500
WORK_MIN = 100
WORK_MAX = 350
CURRENCY = "💰"

WORK_MESSAGES = [
    "عملت في المطعم وكسبت", "أصلحت سيارة وكسبت", "بعت بضاعة وكسبت",
    "شغلت في البناء وكسبت", "كتبت مقال وكسبت", "برمجت تطبيق وكسبت",
    "صممت شعار وكسبت", "درّست طلاب وكسبت", "لعبت في الاستوديو وكسبت"
]

class Economy(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def get_balance(self, user_id, guild_id):
        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute(
                'SELECT balance, bank FROM economy WHERE user_id = ? AND guild_id = ?',
                (user_id, guild_id)
            ) as cursor:
                row = await cursor.fetchone()
        return row if row else (0, 0)

    async def update_balance(self, user_id, guild_id, amount, bank_amount=0):
        async with aiosqlite.connect('data/database.db') as db:
            await db.execute('''
                INSERT INTO economy (user_id, guild_id, balance, bank)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id, guild_id) DO UPDATE SET
                    balance = balance + ?,
                    bank = bank + ?
            ''', (user_id, guild_id, max(0, amount), max(0, bank_amount), amount, bank_amount))
            await db.commit()

    @commands.command(name='balance', aliases=['bal', 'money'])
    async def balance(self, ctx, member: discord.Member = None):
        """عرض الرصيد"""
        member = member or ctx.author
        balance, bank = await self.get_balance(member.id, ctx.guild.id)
        embed = discord.Embed(title=f"{CURRENCY} رصيد {member.display_name}", color=discord.Color.gold())
        embed.add_field(name="المحفظة", value=f"**{balance:,}** {CURRENCY}", inline=True)
        embed.add_field(name="البنك", value=f"**{bank:,}** {CURRENCY}", inline=True)
        embed.add_field(name="الإجمالي", value=f"**{balance+bank:,}** {CURRENCY}", inline=True)
        embed.set_thumbnail(url=member.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command(name='daily')
    @commands.cooldown(1, 86400, commands.BucketType.user)
    async def daily(self, ctx):
        """مكافأة يومية"""
        await self.update_balance(ctx.author.id, ctx.guild.id, DAILY_AMOUNT)
        embed = discord.Embed(
            title="🎁 مكافأة يومية",
            description=f"حصلت على **{DAILY_AMOUNT:,}** {CURRENCY}!\nعد غداً للحصول على مكافأتك التالية.",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    @daily.error
    async def daily_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            hours = int(error.retry_after // 3600)
            minutes = int((error.retry_after % 3600) // 60)
            await ctx.send(f"⏱️ عد بعد **{hours}** ساعة و **{minutes}** دقيقة للمكافأة اليومية")

    @commands.command(name='work')
    @commands.cooldown(1, 3600, commands.BucketType.user)
    async def work(self, ctx):
        """اشتغل وكسب فلوس"""
        amount = random.randint(WORK_MIN, WORK_MAX)
        msg = random.choice(WORK_MESSAGES)
        await self.update_balance(ctx.author.id, ctx.guild.id, amount)
        embed = discord.Embed(
            title="💼 عمل",
            description=f"{msg} **{amount:,}** {CURRENCY}!",
            color=discord.Color.blue()
        )
        await ctx.send(embed=embed)

    @work.error
    async def work_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            minutes = int(error.retry_after // 60)
            await ctx.send(f"⏱️ تعبت! استرح **{minutes}** دقيقة قبل العمل مجدداً")

    @commands.command(name='deposit', aliases=['dep'])
    async def deposit(self, ctx, amount: str):
        """إيداع في البنك"""
        balance, bank = await self.get_balance(ctx.author.id, ctx.guild.id)
        if amount.lower() == 'all':
            amount = balance
        else:
            amount = int(amount)
        if amount <= 0:
            return await ctx.send("❌ المبلغ يجب أن يكون أكبر من صفر")
        if amount > balance:
            return await ctx.send(f"❌ ليس لديك كافي في المحفظة. رصيدك: **{balance:,}** {CURRENCY}")
        await self.update_balance(ctx.author.id, ctx.guild.id, -amount, amount)
        embed = discord.Embed(title="🏦 إيداع", description=f"تم إيداع **{amount:,}** {CURRENCY} في البنك", color=discord.Color.green())
        await ctx.send(embed=embed)

    @commands.command(name='withdraw', aliases=['with'])
    async def withdraw(self, ctx, amount: str):
        """سحب من البنك"""
        balance, bank = await self.get_balance(ctx.author.id, ctx.guild.id)
        if amount.lower() == 'all':
            amount = bank
        else:
            amount = int(amount)
        if amount <= 0:
            return await ctx.send("❌ المبلغ يجب أن يكون أكبر من صفر")
        if amount > bank:
            return await ctx.send(f"❌ ليس لديك كافي في البنك. رصيد البنك: **{bank:,}** {CURRENCY}")
        await self.update_balance(ctx.author.id, ctx.guild.id, amount, -amount)
        embed = discord.Embed(title="🏦 سحب", description=f"تم سحب **{amount:,}** {CURRENCY} من البنك", color=discord.Color.green())
        await ctx.send(embed=embed)

    @commands.command(name='transfer', aliases=['pay', 'give'])
    async def transfer(self, ctx, member: discord.Member, amount: int):
        """تحويل فلوس لعضو"""
        if member == ctx.author:
            return await ctx.send("❌ لا تستطيع التحويل لنفسك")
        if amount <= 0:
            return await ctx.send("❌ المبلغ يجب أن يكون أكبر من صفر")
        balance, _ = await self.get_balance(ctx.author.id, ctx.guild.id)
        if amount > balance:
            return await ctx.send(f"❌ ليس لديك كافي. رصيدك: **{balance:,}** {CURRENCY}")
        await self.update_balance(ctx.author.id, ctx.guild.id, -amount)
        await self.update_balance(member.id, ctx.guild.id, amount)
        embed = discord.Embed(
            title="💸 تحويل",
            description=f"تم تحويل **{amount:,}** {CURRENCY} من {ctx.author.mention} إلى {member.mention}",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    @commands.command(name='richlist', aliases=['richleaderboard'])
    async def rich_list(self, ctx):
        """أغنى الأعضاء"""
        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute(
                'SELECT user_id, balance+bank as total FROM economy WHERE guild_id = ? ORDER BY total DESC LIMIT 10',
                (ctx.guild.id,)
            ) as cursor:
                rows = await cursor.fetchall()
        if not rows:
            return await ctx.send("❌ لا يوجد بيانات بعد!")
        embed = discord.Embed(title=f"💰 أغنى أعضاء {ctx.guild.name}", color=discord.Color.gold())
        medals = ["🥇", "🥈", "🥉"]
        desc = ""
        for i, (user_id, total) in enumerate(rows):
            member = ctx.guild.get_member(user_id)
            name = member.display_name if member else f"ID: {user_id}"
            medal = medals[i] if i < 3 else f"**{i+1}.**"
            desc += f"{medal} {name} — **{total:,}** {CURRENCY}\n"
        embed.description = desc
        await ctx.send(embed=embed)

    @commands.command(name='addmoney')
    @commands.has_permissions(administrator=True)
    async def add_money(self, ctx, member: discord.Member, amount: int):
        """إضافة فلوس لعضو (أدمن)"""
        await self.update_balance(member.id, ctx.guild.id, amount)
        await ctx.send(f"✅ تم إضافة **{amount:,}** {CURRENCY} لـ {member.mention}")

    @commands.command(name='removemoney')
    @commands.has_permissions(administrator=True)
    async def remove_money(self, ctx, member: discord.Member, amount: int):
        """إزالة فلوس من عضو (أدمن)"""
        await self.update_balance(member.id, ctx.guild.id, -amount)
        await ctx.send(f"✅ تم خصم **{amount:,}** {CURRENCY} من {member.mention}")

async def setup(bot):
    await bot.add_cog(Economy(bot))
