import discord
from discord.ext import commands
from discord import app_commands
import aiosqlite

class Welcome(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def get_settings(self, guild_id):
        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute(
                'SELECT welcome_channel, auto_role FROM guild_settings WHERE guild_id = ?',
                (guild_id,)
            ) as cursor:
                row = await cursor.fetchone()
                return row if row else (None, None)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        guild = member.guild
        settings = await self.get_settings(guild.id)
        welcome_channel_id, auto_role_id = settings

        # رسالة الترحيب
        if welcome_channel_id:
            channel = guild.get_channel(welcome_channel_id)
            if channel:
                embed = discord.Embed(
                    title=f"🎉 مرحباً بك في {guild.name}!",
                    description=(
                        f"أهلاً وسهلاً {member.mention}!\n\n"
                        f"أنت العضو رقم **{guild.member_count}** في السيرفر.\n"
                        f"نتمنى لك وقتاً ممتعاً معنا! 🌟"
                    ),
                    color=discord.Color.green()
                )
                embed.set_thumbnail(url=member.display_avatar.url)
                embed.set_footer(text=f"انضم في {member.joined_at.strftime('%Y-%m-%d')}")
                await channel.send(embed=embed)

        # الرتبة التلقائية
        if auto_role_id:
            role = guild.get_role(auto_role_id)
            if role:
                try:
                    await member.add_roles(role, reason="رتبة تلقائية للأعضاء الجدد")
                except discord.Forbidden:
                    pass

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        guild = member.guild
        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute(
                'SELECT welcome_channel FROM guild_settings WHERE guild_id = ?',
                (guild.id,)
            ) as cursor:
                row = await cursor.fetchone()
        
        if row and row[0]:
            channel = guild.get_channel(row[0])
            if channel:
                embed = discord.Embed(
                    title=f"👋 وداعاً {member.name}",
                    description=f"غادر **{member.mention}** السيرفر.\nنتمنى أن نراك مجدداً! 💙",
                    color=discord.Color.red()
                )
                embed.set_thumbnail(url=member.display_avatar.url)
                await channel.send(embed=embed)

    @commands.command(name='setwelcome')
    @commands.has_permissions(administrator=True)
    async def set_welcome(self, ctx, channel: discord.TextChannel):
        """تعيين قناة الترحيب"""
        async with aiosqlite.connect('data/database.db') as db:
            await db.execute('''
                INSERT INTO guild_settings (guild_id, welcome_channel)
                VALUES (?, ?)
                ON CONFLICT(guild_id) DO UPDATE SET welcome_channel = ?
            ''', (ctx.guild.id, channel.id, channel.id))
            await db.commit()
        
        embed = discord.Embed(
            title="✅ تم التعيين",
            description=f"تم تعيين قناة الترحيب على {channel.mention}",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    @commands.command(name='setautorole')
    @commands.has_permissions(administrator=True)
    async def set_auto_role(self, ctx, role: discord.Role):
        """تعيين رتبة تلقائية للأعضاء الجدد"""
        async with aiosqlite.connect('data/database.db') as db:
            await db.execute('''
                INSERT INTO guild_settings (guild_id, auto_role)
                VALUES (?, ?)
                ON CONFLICT(guild_id) DO UPDATE SET auto_role = ?
            ''', (ctx.guild.id, role.id, role.id))
            await db.commit()
        
        embed = discord.Embed(
            title="✅ تم التعيين",
            description=f"سيحصل الأعضاء الجدد على رتبة {role.mention} تلقائياً",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    @commands.command(name='testwelcome')
    @commands.has_permissions(administrator=True)
    async def test_welcome(self, ctx):
        """اختبار رسالة الترحيب"""
        await self.on_member_join(ctx.author)
        await ctx.send("✅ تم إرسال رسالة ترحيب تجريبية!", delete_after=3)

async def setup(bot):
    await bot.add_cog(Welcome(bot))
