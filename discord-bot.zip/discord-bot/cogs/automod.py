import discord
from discord.ext import commands
import aiosqlite
import re

BAD_WORDS = ['spam', 'scam']  # يمكن تعديل القائمة

class AutoMod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.invite_pattern = re.compile(r'discord\.gg/\S+|discord\.com/invite/\S+', re.IGNORECASE)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return
        if message.author.guild_permissions.manage_messages:
            return

        content = message.content.lower()

        # فحص الكلمات المحظورة
        for word in BAD_WORDS:
            if word in content:
                await message.delete()
                embed = discord.Embed(
                    title="🚫 رسالة محذوفة",
                    description=f"{message.author.mention} رسالتك تحتوي على كلمات غير مسموح بها.",
                    color=discord.Color.red()
                )
                await message.channel.send(embed=embed, delete_after=5)
                return

        # فحص روابط الدعوة
        if self.invite_pattern.search(message.content):
            await message.delete()
            embed = discord.Embed(
                title="🚫 رابط دعوة محذوف",
                description=f"{message.author.mention} لا يُسمح بمشاركة روابط دعوة ديسكورد.",
                color=discord.Color.red()
            )
            await message.channel.send(embed=embed, delete_after=5)
            return

    @commands.command(name='addbadword')
    @commands.has_permissions(administrator=True)
    async def add_bad_word(self, ctx, *, word: str):
        """إضافة كلمة محظورة"""
        BAD_WORDS.append(word.lower())
        await ctx.send(f"✅ تمت إضافة الكلمة المحظورة: `{word}`")

    @commands.command(name='removebadword')
    @commands.has_permissions(administrator=True)
    async def remove_bad_word(self, ctx, *, word: str):
        """إزالة كلمة محظورة"""
        if word.lower() in BAD_WORDS:
            BAD_WORDS.remove(word.lower())
            await ctx.send(f"✅ تمت إزالة الكلمة: `{word}`")
        else:
            await ctx.send(f"❌ الكلمة `{word}` غير موجودة في القائمة")

    @commands.command(name='badwords')
    @commands.has_permissions(administrator=True)
    async def list_bad_words(self, ctx):
        """عرض الكلمات المحظورة"""
        if BAD_WORDS:
            await ctx.send(f"📋 الكلمات المحظورة: `{', '.join(BAD_WORDS)}`")
        else:
            await ctx.send("✅ لا توجد كلمات محظورة")

async def setup(bot):
    await bot.add_cog(AutoMod(bot))
