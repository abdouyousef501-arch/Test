import discord
from discord.ext import commands
import random
import asyncio
import aiosqlite

CURRENCY = "💰"

TRIVIA_QUESTIONS = [
    {"q": "ما عاصمة المملكة العربية السعودية؟", "a": "الرياض", "choices": ["الرياض", "جدة", "مكة", "الدمام"]},
    {"q": "كم عدد أيام السنة؟", "a": "365", "choices": ["365", "360", "366", "364"]},
    {"q": "ما هو أكبر كوكب في المجموعة الشمسية؟", "a": "المشتري", "choices": ["المشتري", "زحل", "الأرض", "أورانوس"]},
    {"q": "من هو مؤسس شركة Apple؟", "a": "ستيف جوبز", "choices": ["ستيف جوبز", "بيل غيتس", "إيلون ماسك", "مارك زوكربيرغ"]},
    {"q": "ما هو أطول نهر في العالم؟", "a": "النيل", "choices": ["النيل", "الأمازون", "المسيسيبي", "اليانغتسي"]},
    {"q": "كم عدد لاعبي كرة القدم في الملعب؟", "a": "22", "choices": ["22", "18", "20", "24"]},
    {"q": "ما هي لغة البرمجة التي نستخدمها لبناء هذا البوت؟", "a": "Python", "choices": ["Python", "Java", "C++", "JavaScript"]},
    {"q": "ما هو أسرع حيوان بري؟", "a": "الفهد", "choices": ["الفهد", "الأسد", "الحصان", "الغزال"]},
]

EIGHT_BALL_RESPONSES = [
    "نعم بالتأكيد! ✅", "لا شك في ذلك ✅", "ربما... 🤔", "لا أعتقد ❌",
    "بالتأكيد لا ❌", "الأمور غير واضحة 🌫️", "اسأل لاحقاً ⏳",
    "الإجابة إيجابية ✅", "الإجابة سلبية ❌", "المستقبل ضبابي 🔮",
    "تركّز وحاول مجدداً 🎯", "لا تعتمد عليه ⚠️",
]

class Games(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def update_balance(self, user_id, guild_id, amount):
        async with aiosqlite.connect('data/database.db') as db:
            await db.execute('''
                INSERT INTO economy (user_id, guild_id, balance)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id, guild_id) DO UPDATE SET balance = MAX(0, balance + ?)
            ''', (user_id, guild_id, max(0, amount), amount))
            await db.commit()

    async def get_balance(self, user_id, guild_id):
        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute('SELECT balance FROM economy WHERE user_id = ? AND guild_id = ?', (user_id, guild_id)) as cursor:
                row = await cursor.fetchone()
        return row[0] if row else 0

    @commands.command(name='coinflip', aliases=['cf', 'flip'])
    async def coinflip(self, ctx, bet: int = 0):
        """رمي عملة - راهن على نتيجة"""
        if bet > 0:
            balance = await self.get_balance(ctx.author.id, ctx.guild.id)
            if bet > balance:
                return await ctx.send(f"❌ ليس لديك كافي! رصيدك: **{balance:,}** {CURRENCY}")

        result = random.choice(["صورة", "كتابة"])
        won = random.choice([True, False])
        
        if bet > 0:
            if won:
                await self.update_balance(ctx.author.id, ctx.guild.id, bet)
                outcome = f"ربحت **{bet:,}** {CURRENCY}! 🎉"
            else:
                await self.update_balance(ctx.author.id, ctx.guild.id, -bet)
                outcome = f"خسرت **{bet:,}** {CURRENCY}! 😢"
        else:
            outcome = ""

        embed = discord.Embed(
            title="🪙 رمي العملة",
            description=f"النتيجة: **{result}**\n{outcome}",
            color=discord.Color.gold() if (bet == 0 or won) else discord.Color.red()
        )
        await ctx.send(embed=embed)

    @commands.command(name='dice', aliases=['roll'])
    async def dice(self, ctx, bet: int = 0):
        """رمي نرد"""
        if bet > 0:
            balance = await self.get_balance(ctx.author.id, ctx.guild.id)
            if bet > balance:
                return await ctx.send(f"❌ ليس لديك كافي! رصيدك: **{balance:,}** {CURRENCY}")

        roll = random.randint(1, 6)
        bot_roll = random.randint(1, 6)
        dice_faces = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"]

        if roll > bot_roll:
            result = "ربحت! 🎉"
            color = discord.Color.green()
            if bet > 0:
                await self.update_balance(ctx.author.id, ctx.guild.id, bet)
        elif roll < bot_roll:
            result = "خسرت! 😢"
            color = discord.Color.red()
            if bet > 0:
                await self.update_balance(ctx.author.id, ctx.guild.id, -bet)
        else:
            result = "تعادل! 🤝"
            color = discord.Color.yellow()

        embed = discord.Embed(title="🎲 رمي النرد", color=color)
        embed.add_field(name="أنت", value=f"{dice_faces[roll-1]} ({roll})", inline=True)
        embed.add_field(name="البوت", value=f"{dice_faces[bot_roll-1]} ({bot_roll})", inline=True)
        embed.add_field(name="النتيجة", value=result, inline=False)
        await ctx.send(embed=embed)

    @commands.command(name='rps')
    async def rps(self, ctx, choice: str):
        """حجر ورقة مقص"""
        choices_map = {
            'حجر': '🪨', 'ورقة': '📄', 'مقص': '✂️',
            'rock': '🪨', 'paper': '📄', 'scissors': '✂️',
            'r': '🪨', 'p': '📄', 's': '✂️'
        }
        
        choice = choice.lower()
        if choice not in choices_map:
            return await ctx.send("❌ اختر: حجر / ورقة / مقص")

        bot_choice = random.choice(['حجر', 'ورقة', 'مقص'])
        wins = {'حجر': 'مقص', 'ورقة': 'حجر', 'مقص': 'ورقة'}
        
        choice_ar = {'rock': 'حجر', 'paper': 'ورقة', 'scissors': 'مقص', 'r': 'حجر', 'p': 'ورقة', 's': 'مقص'}.get(choice, choice)
        
        if choice_ar == bot_choice:
            result, color = "تعادل! 🤝", discord.Color.yellow()
        elif wins[choice_ar] == bot_choice:
            result, color = "ربحت! 🎉", discord.Color.green()
        else:
            result, color = "خسرت! 😢", discord.Color.red()

        embed = discord.Embed(title="✂️ حجر ورقة مقص", color=color)
        embed.add_field(name="اختيارك", value=f"{choices_map.get(choice_ar, choice_ar)} {choice_ar}", inline=True)
        embed.add_field(name="اختيار البوت", value=f"{choices_map[bot_choice]} {bot_choice}", inline=True)
        embed.add_field(name="النتيجة", value=result, inline=False)
        await ctx.send(embed=embed)

    @commands.command(name='8ball', aliases=['magic'])
    async def eight_ball(self, ctx, *, question: str):
        """كرة السحر - اسأل أي سؤال"""
        response = random.choice(EIGHT_BALL_RESPONSES)
        embed = discord.Embed(title="🔮 كرة السحر", color=discord.Color.purple())
        embed.add_field(name="سؤالك", value=question, inline=False)
        embed.add_field(name="الإجابة", value=response, inline=False)
        await ctx.send(embed=embed)

    @commands.command(name='trivia')
    async def trivia(self, ctx):
        """سؤال ثقافي"""
        question = random.choice(TRIVIA_QUESTIONS)
        random.shuffle(question['choices'])
        
        letters = ['🇦', '🇧', '🇨', '🇩']
        choices_text = "\n".join([f"{letters[i]} {choice}" for i, choice in enumerate(question['choices'])])
        
        embed = discord.Embed(
            title="🧠 سؤال ثقافي",
            description=f"**{question['q']}**\n\n{choices_text}\n\n⏱️ لديك **15** ثانية للإجابة!",
            color=discord.Color.blue()
        )
        msg = await ctx.send(embed=embed)
        
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        
        try:
            answer = await self.bot.wait_for('message', timeout=15.0, check=check)
            user_answer = answer.content.strip()
            
            correct = question['a']
            is_correct = user_answer.lower() == correct.lower() or user_answer in ['أ', 'ب', 'ج', 'د', 'a', 'b', 'c', 'd']
            
            if user_answer.lower() == correct.lower():
                reward = 100
                await self.update_balance(ctx.author.id, ctx.guild.id, reward)
                result_embed = discord.Embed(
                    title="✅ إجابة صحيحة!",
                    description=f"أحسنت! الإجابة هي: **{correct}**\nحصلت على **{reward}** {CURRENCY}!",
                    color=discord.Color.green()
                )
            else:
                result_embed = discord.Embed(
                    title="❌ إجابة خاطئة",
                    description=f"الإجابة الصحيحة هي: **{correct}**",
                    color=discord.Color.red()
                )
            await ctx.send(embed=result_embed)
        except asyncio.TimeoutError:
            await ctx.send(f"⏱️ انتهى الوقت! الإجابة الصحيحة: **{question['a']}**")

    @commands.command(name='slots')
    async def slots(self, ctx, bet: int = 50):
        """سلوت ماشين"""
        if bet < 10:
            return await ctx.send("❌ الحد الأدنى للرهان هو 10")
        
        balance = await self.get_balance(ctx.author.id, ctx.guild.id)
        if bet > balance:
            return await ctx.send(f"❌ ليس لديك كافي! رصيدك: **{balance:,}** {CURRENCY}")

        symbols = ['🍒', '🍋', '🍊', '🍇', '⭐', '💎', '7️⃣']
        weights = [30, 25, 20, 15, 6, 3, 1]
        
        result = random.choices(symbols, weights=weights, k=3)
        
        if result[0] == result[1] == result[2]:
            if result[0] == '7️⃣':
                multiplier = 50
            elif result[0] == '💎':
                multiplier = 20
            elif result[0] == '⭐':
                multiplier = 10
            else:
                multiplier = 5
            winnings = bet * multiplier
            await self.update_balance(ctx.author.id, ctx.guild.id, winnings - bet)
            outcome = f"🎰 **JACKPOT!** ربحت **{winnings:,}** {CURRENCY}!"
            color = discord.Color.gold()
        elif result[0] == result[1] or result[1] == result[2]:
            winnings = bet * 2
            await self.update_balance(ctx.author.id, ctx.guild.id, winnings - bet)
            outcome = f"✨ اثنان متطابقان! ربحت **{winnings:,}** {CURRENCY}!"
            color = discord.Color.green()
        else:
            await self.update_balance(ctx.author.id, ctx.guild.id, -bet)
            outcome = f"😢 خسرت **{bet:,}** {CURRENCY}!"
            color = discord.Color.red()

        embed = discord.Embed(title="🎰 سلوت ماشين", color=color)
        embed.add_field(name="النتيجة", value=f"| {result[0]} | {result[1]} | {result[2]} |", inline=False)
        embed.add_field(name="النتيجة", value=outcome, inline=False)
        await ctx.send(embed=embed)

    @commands.command(name='guess')
    async def guess(self, ctx):
        """خمن الرقم بين 1 و 100"""
        number = random.randint(1, 100)
        attempts = 0
        max_attempts = 7

        embed = discord.Embed(
            title="🔢 خمن الرقم",
            description=f"خمّن رقماً بين **1** و **100**\nلديك **{max_attempts}** محاولات!",
            color=discord.Color.blue()
        )
        await ctx.send(embed=embed)

        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel and m.content.isdigit()

        while attempts < max_attempts:
            try:
                msg = await self.bot.wait_for('message', timeout=30.0, check=check)
                guess = int(msg.content)
                attempts += 1
                remaining = max_attempts - attempts

                if guess == number:
                    reward = max(50, 200 - (attempts * 20))
                    await self.update_balance(ctx.author.id, ctx.guild.id, reward)
                    await ctx.send(embed=discord.Embed(
                        title="🎉 صحيح!",
                        description=f"الرقم هو **{number}**!\nوجدته في **{attempts}** محاولة وربحت **{reward}** {CURRENCY}!",
                        color=discord.Color.green()
                    ))
                    return
                elif guess < number:
                    hint = "📈 الرقم أكبر"
                else:
                    hint = "📉 الرقم أصغر"

                if remaining > 0:
                    await ctx.send(f"{hint} | تبقى لك **{remaining}** محاولة")
                else:
                    await ctx.send(embed=discord.Embed(
                        title="❌ انتهت المحاولات",
                        description=f"الرقم كان **{number}**! حظاً أوفر المرة القادمة.",
                        color=discord.Color.red()
                    ))
                    return
            except asyncio.TimeoutError:
                await ctx.send(f"⏱️ انتهى الوقت! الرقم كان **{number}**")
                return

async def setup(bot):
    await bot.add_cog(Games(bot))
