import discord
from discord.ext import commands
import aiosqlite
import random
import math

def xp_for_level(level):
    """حساب XP المطلوب للمستوى التالي"""
    return int(100 * (level ** 1.5))

def get_level_from_xp(xp):
    """حساب المستوى من XP"""
    level = 0
    while xp >= xp_for_level(level + 1):
        xp -= xp_for_level(level + 1)
        level += 1
    return level

class Leveling(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.xp_cooldown = {}

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return
        
        user_id = message.author.id
        guild_id = message.guild.id
        key = f"{user_id}-{guild_id}"
        
        # كولداون 60 ثانية
        import time
        now = time.time()
        if key in self.xp_cooldown and now - self.xp_cooldown[key] < 60:
            return
        self.xp_cooldown[key] = now
        
        # إضافة XP عشوائي
        xp_gain = random.randint(15, 25)
        
        async with aiosqlite.connect('data/database.db') as db:
            await db.execute('''
                INSERT INTO levels (user_id, guild_id, xp, level, messages)
                VALUES (?, ?, ?, 0, 1)
                ON CONFLICT(user_id, guild_id) DO UPDATE SET
                    xp = xp + ?,
                    messages = messages + 1
            ''', (user_id, guild_id, xp_gain, xp_gain))
            
            async with db.execute(
                'SELECT xp, level FROM levels WHERE user_id = ? AND guild_id = ?',
                (user_id, guild_id)
            ) as cursor:
                row = await cursor.fetchone()
            
            if row:
                total_xp, current_level = row
                new_level = get_level_from_xp(total_xp)
                
                if new_level > current_level:
                    await db.execute(
                        'UPDATE levels SET level = ? WHERE user_id = ? AND guild_id = ?',
                        (new_level, user_id, guild_id)
                    )
                    
                    # إشعار ترقية المستوى
                    async with db.execute(
                        'SELECT level_channel FROM guild_settings WHERE guild_id = ?',
                        (guild_id,)
                    ) as cursor:
                        settings = await cursor.fetchone()
                    
                    channel = None
                    if settings and settings[0]:
                        channel = message.guild.get_channel(settings[0])
                    if not channel:
                        channel = message.channel
                    
                    embed = discord.Embed(
                        title="🎉 ترقية مستوى!",
                        description=(
                            f"تهانينا {message.author.mention}!\n"
                            f"وصلت إلى **المستوى {new_level}** 🌟"
                        ),
                        color=discord.Color.gold()
                    )
                    embed.set_thumbnail(url=message.author.display_avatar.url)
                    await channel.send(embed=embed)
            
            await db.commit()

    @commands.command(name='rank', aliases=['level', 'xp'])
    async def rank(self, ctx, member: discord.Member = None):
        """عرض مستوى عضو"""
        member = member or ctx.author
        
        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute(
                'SELECT xp, level, messages FROM levels WHERE user_id = ? AND guild_id = ?',
                (member.id, ctx.guild.id)
            ) as cursor:
                row = await cursor.fetchone()
            
            # الترتيب
            async with db.execute(
                'SELECT COUNT(*) FROM levels WHERE guild_id = ? AND xp > (SELECT xp FROM levels WHERE user_id = ? AND guild_id = ?)',
                (ctx.guild.id, member.id, ctx.guild.id)
            ) as cursor:
                rank_row = await cursor.fetchone()
        
        if not row:
            xp, level, messages = 0, 0, 0
        else:
            xp, level, messages = row
        
        rank_num = (rank_row[0] + 1) if rank_row else 1
        next_level_xp = xp_for_level(level + 1)
        current_xp = xp - sum(xp_for_level(i + 1) for i in range(level))
        
        # شريط التقدم
        bar_length = 20
        filled = int(bar_length * current_xp / next_level_xp) if next_level_xp > 0 else 0
        bar = "█" * filled + "░" * (bar_length - filled)
        
        embed = discord.Embed(
            title=f"⭐ مستوى {member.display_name}",
            color=discord.Color.blue()
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="المستوى", value=f"**{level}**", inline=True)
        embed.add_field(name="الترتيب", value=f"**#{rank_num}**", inline=True)
        embed.add_field(name="الرسائل", value=f"**{messages:,}**", inline=True)
        embed.add_field(
            name=f"XP: {current_xp:,} / {next_level_xp:,}",
            value=f"`{bar}`",
            inline=False
        )
        embed.add_field(name="إجمالي XP", value=f"**{xp:,}**", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name='leaderboard', aliases=['lb', 'top'])
    async def leaderboard(self, ctx):
        """لوحة الصدارة"""
        async with aiosqlite.connect('data/database.db') as db:
            async with db.execute(
                'SELECT user_id, xp, level FROM levels WHERE guild_id = ? ORDER BY xp DESC LIMIT 10',
                (ctx.guild.id,)
            ) as cursor:
                rows = await cursor.fetchall()
        
        if not rows:
            await ctx.send("❌ لا يوجد بيانات بعد!")
            return
        
        embed = discord.Embed(
            title=f"🏆 لوحة الصدارة - {ctx.guild.name}",
            color=discord.Color.gold()
        )
        
        medals = ["🥇", "🥈", "🥉"]
        description = ""
        for i, (user_id, xp, level) in enumerate(rows):
            member = ctx.guild.get_member(user_id)
            name = member.display_name if member else f"مستخدم ({user_id})"
            medal = medals[i] if i < 3 else f"**{i+1}.**"
            description += f"{medal} {name} — المستوى **{level}** | **{xp:,}** XP\n"
        
        embed.description = description
        embed.set_footer(text=f"طلب بواسطة {ctx.author.display_name}")
        await ctx.send(embed=embed)

    @commands.command(name='givexp')
    @commands.has_permissions(administrator=True)
    async def give_xp(self, ctx, member: discord.Member, amount: int):
        """إعطاء XP لعضو"""
        async with aiosqlite.connect('data/database.db') as db:
            await db.execute('''
                INSERT INTO levels (user_id, guild_id, xp)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id, guild_id) DO UPDATE SET xp = xp + ?
            ''', (member.id, ctx.guild.id, amount, amount))
            await db.commit()
        
        embed = discord.Embed(
            title="✅ تم إضافة XP",
            description=f"تم إضافة **{amount:,} XP** لـ {member.mention}",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    @commands.command(name='resetxp')
    @commands.has_permissions(administrator=True)
    async def reset_xp(self, ctx, member: discord.Member):
        """إعادة تعيين XP عضو"""
        async with aiosqlite.connect('data/database.db') as db:
            await db.execute(
                'UPDATE levels SET xp = 0, level = 0, messages = 0 WHERE user_id = ? AND guild_id = ?',
                (member.id, ctx.guild.id)
            )
            await db.commit()
        
        await ctx.send(f"✅ تم إعادة تعيين XP لـ {member.mention}")

    @commands.command(name='setlevelchannel')
    @commands.has_permissions(administrator=True)
    async def set_level_channel(self, ctx, channel: discord.TextChannel):
        """تعيين قناة إشعارات المستوى"""
        async with aiosqlite.connect('data/database.db') as db:
            await db.execute('''
                INSERT INTO guild_settings (guild_id, level_channel)
                VALUES (?, ?)
                ON CONFLICT(guild_id) DO UPDATE SET level_channel = ?
            ''', (ctx.guild.id, channel.id, channel.id))
            await db.commit()
        
        await ctx.send(f"✅ تم تعيين قناة المستويات على {channel.mention}")

async def setup(bot):
    await bot.add_cog(Leveling(bot))
