"""
ملف keep_alive.py - يُستخدم للاستضافة المجانية على Render أو Railway
يشغل سيرفر ويب صغير حتى لا ينام البوت
"""
from flask import Flask
from threading import Thread
import logging

# إخفاء سجلات Flask
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

app = Flask('')

@app.route('/')
def home():
    return """
    <html>
    <head><title>Test Bot</title></head>
    <body style="background:#2C2F33;color:white;font-family:Arial;text-align:center;padding:50px">
        <h1>🤖 Test Bot</h1>
        <p style="color:#43B581">✅ البوت يعمل بشكل طبيعي!</p>
        <p>Discord Bot - Online 24/7</p>
    </body>
    </html>
    """

@app.route('/health')
def health():
    return {"status": "online", "bot": "Test"}

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.daemon = True
    t.start()
    print("✅ Keep-alive server started on port 8080")
